import { Box } from '@chakra-ui/react'
import React from 'react'

function RegisterForm() {
    return (
        <Box w={'100%'}>
            
        </Box>
    )
}

export default RegisterForm