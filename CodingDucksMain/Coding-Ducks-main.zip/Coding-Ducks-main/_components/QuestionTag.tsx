import { Box } from "@chakra-ui/react"

function QuestionTag() {
  return (
    <Box></Box>
  )
}

export default QuestionTag